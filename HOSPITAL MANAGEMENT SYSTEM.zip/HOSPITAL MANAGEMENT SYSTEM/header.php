<html>
<head>
<link rel="shortcut icon" type="image/x-icon" href="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSdRoMCJDW_zv-x3a8CnKvRGVONz67yJqoNcw&usqp=CAU" />
<!-- <link rel="shortcut icon" type="image/x-icon" href="images/favicon.png" /> -->
</head>
</html>